<!DOCTYPE html>
<html>
<head>
	<title>HOME</title>
		<h1><p text align="center">SELAMAT DATANG</p></h1>
		<h3><p text align="center">Ini adalah website pribadi saya, dimana untuk memenuhi tugas pertemuan 6 dalam mata kuliah web programming I </p></h3>
</head>
<body bgcolor="#B0C4DE">
	<a href="http://www.bsi.ac.id/ubsi/index.ajax/"><img src="introducing-myself.jpg" align="right" style=”width:300px;height:150px;” border="5"></a>
<p>
	Hallo, perkenalkan nama saya Raisa Nurul Fadillah biasa dipanggil echa. Saya adalah anak kedua dari tiga bersaudara.<br>
	Sejak SMK saya sangat bercita-cita untuk kuliah. Hal ini didorong oleh lingkungan tempat saya belajar yang semuanya sangat ingin berkuliah juga, lalu saya mengikuti SNMPTN dan SBMPTN namun hasilnya tidak seperti yang saya harapkan.<br>
	Hingga akhirnya saya menunda untuk berkuliah dan ingin bekerja dahulu, sampai saat nya tiba saya memutusakan untuk mendaftar kuliah di UNIVERSITAS BINA SARANA INFORMATIKA dan mengambil jurusan SISTEM INFORMASI dengan jenjang pendidikan Diploma.<br>
	Selama berkuliah saya banyak melakukan hal baru karena ini pertama kalinya bagi saya melihat dan mempelajari hal-hal yang berkaitan dengan dunia IT, dimana pengcodingan dan bahasa pemrograman sangat asing bagi saya namun saya menikmatinya walaupun sempat merasa kesulitan namun saya tetap semangat. Karena ini bukan hanya hidup perkuliahan saya sendiri, tetapi juga ada harapan dari orang tua dan keluarga saya yang menunggu saya lulus dengan hasil yang memuaskan hingga saatnya kelulusan itu tiba dan saya bisa bekerja di perusahaan yang saya inginkan dengan skill yang saya punya.</p><br>
	<p text align="center">
	<a href="halamandatadiri.php">DATA DIRI</a><br>
	<a href="halamandataakademik.php">DATA AKADEMIK</a><br>
	<a href="halamankomentar.php">KOMENTAR</a>
<hr>
</body>
</html>
