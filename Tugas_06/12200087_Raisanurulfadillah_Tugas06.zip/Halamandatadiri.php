<!DOCTYPE html>
<html>
<head>
  <title>DATA DIRI</title>
</head>
  <h2>HALAMAN DATA DIRI</h2>
<body bgcolor="#B0C4DE">
  <img src= raisa.jpeg width="10%" ><br>
  <ul>
    <li>Nim             : 12200087</li>
    <li>Nama            : Raisa Nurul Fadillah</li>
    <li>Tempat Tanggal Lahir    : Bogor, 17 November 1999</li>
    <li>Jenis Kelamin   : Perempuan</li>
    <li>Agama           : Islam</li>
    <li>Email           : nraisaaf@gmail.com</li>
    <li>Riwayat Pendidikan  :</li>
    <ul type="square">
      <li>MI Hidayatul Khoeriah</li>
      <li>SMP Putra Pakuan</li>
      <li>SMK Negeri 1 Cibinong</li>
    </ul>
    <li>Hobi      :</li>
    <ul type="square">
      <li>Membaca Novel</li>
      <li>Berkemah</li>
    </ul>
    <p> Saya lulusan SMK NEGERI 1 CIBINONG jurusan Teknik Gambar Bangunan Tahun 2018. Setelah gagal masuk PTN saya memutuskan untuk bekerja sebagai pengawas dan admin dalam proyek pekerjaan pembangunan masjid di area Universitas Djuanda Bogor.
      <p><a align text="center" href="Home.php">HOME</a></p>
</body>
</html>