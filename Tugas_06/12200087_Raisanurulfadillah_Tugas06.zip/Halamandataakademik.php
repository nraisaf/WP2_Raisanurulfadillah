<!DOCTYPE html>
<html>
<head>
	<title>DATA AKADEMIK</title>
	<h2><p text align="center">TABEL DATA AKADEMIK</p></h2>

</head>
<body bgcolor="#B0C4DE">
	<table align="center" border="1" cellspacing="5" cellpadding="10" width="50%">
	<tr>
  	   <td align="center">Program studi</td> </p>
  	   <td align="center">:</td>
  	   <td align="center">Sistem Informasi</td>
  	</tr>
  	<tr>
  	   <td align="center">Tahun Masuk</td>
  	   <td align="center">:</td>
  	   <td align="center">2020</td>
  	</tr>
    <tr>
   	   <td align="center">Lokasi Kampus</td>
  	   <td align="center">:</td>
  	   <td align="center">Kampus Bogor</td>
  	</tr>
  	<tr>
  		<td align="center">Kelas</td>
  	   <td align="center">:</td>
  	   <td align="center">12.2A.13</td>
  	 </tr>
  	 <tr>
  	 	<td align="center">Semester</td>
  	   <td align="center">:</td>
  	   <td align="center">Semester 2</td>
  	</tr>
  	<tr>
  		<td align="center">Alasan Memilih Program Studi SI</td>
  	   <td align="center">:</td>
  	   <td align="center">Karena Tertarik Dengan Bahasa Pemprograman</td>
  	   </tr> </table>
  	<a href="home.php">HOME</a>
</body>
</html>